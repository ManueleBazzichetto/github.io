## Welcome to my personal webpage (**still under construction** :construction_worker_man:)

My name is Manuele Bazzichetto, and I am a vegetation ecologist broadly interested in biological invasions, biogeography, species distribution modelling.

Here a picture of me (when I had long hairs :slightly_smiling_face:):

![MB](images/DSC_2169.jpg)

As soon as I can, I will share on this web-site all things related to my research and personal interests, and some R experiment.

